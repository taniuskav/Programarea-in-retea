(function() {
    // check websockets support
    var socket = window.WebSocket || window.MozWebSocket;
    var nick = document.getElementById('nick');
    var nickName;
    var now = new Date();

    function beginConn(){
        // get message inputs
        var form = document.getElementById('form');

        var msg = document.getElementById('message');
        var list = document.getElementById('list-messages');

        list.innerHTML += "Waiting for connection </br>";

        // create a new WebSocket and connect
        window.ws = new socket('ws://localhost:8181');

        // when connection is established
        ws.onopen = function() {
            list.innerHTML += "Connection opened. </br>";
            var time = now.getHours() + ':' + now.getMinutes() + ':' + now.getSeconds();
            ws.send("1" + "\0" + nickName + "\0" + time);
        };

        // get message from server
        ws.onmessage = function(e) {
            var now = new Date();
            var type = e.data.substring(0,1);
            var parts = e.data.split('\0');

            switch(type) {
                // user came online
                case "1":
                    list.innerHTML += "<span class='user'>" + parts[1] + " : </span><span class='time'>" +
                    parts[2] + " </span>" + parts[3] + "</br>";
                    break;

                // user leaves the net
                case "2":
                    list.innerHTML += "<span class='user'>" + parts[1] + " : </span><span class='time'>" +
                    parts[2] + " </span>" + parts[3] + "</br>";
                    break;

                // private message
                case "/":
                    list.innerHTML += "<span class='user'>" + parts[2] + " :</span>" + "<span class='user'>@" + parts[1] +
                    "</span><span class='time'>" + parts[3] + " :</span>" + parts[4] + "</br>";
                    break;

                // message to all users
                default:
                    list.innerHTML += "<span class='user'>" + parts[0] + " :</span><span class='time'>" +
                    parts[1] + " </span>" + parts[2] + "</br>";
                    break;
            }
        };

        ws.onclose = function() {
            list.innerHTML += "Connection closed. </br>";
        };

        form.addEventListener('submit', function(e){
            e.preventDefault();

            // get data from message input field
            var message = msg.value;

            // get current time
            var time = now.getHours() + ':' + now.getMinutes() + ':' + now.getSeconds();

            // send a private message
            if(message.substring(0, 1) === "/") {
                var user = message.match(/[^\/]\w+/i);
                message = message.match(/[^\/\w+].+/i);

                // for the message structure
                var data = "/" + "\0" + user + "\0" + nickName + "\0" + time + "\0" + message;
                ws.send(data);
            }

            // send a public message
            else {
                message = nickName + "\0" + time + "\0" + message;
                ws.send(message);
            }
            msg.value = "";
        });
    }

    var connect = document.getElementById("connect");
    connect.addEventListener('click', function() {
        if(connect.value === "Connect") {
            if(nick.value.length > 3) {
                beginConn();
                connect.value = "Disconnect";
                nickName = nick.value;
            }
            else {
                alert("Please enter a corect name more then 3 characters !!");
            }
        }
        else {
            connect.value = "Connect";
            var time = now.getHours() + ':' + now.getMinutes() + ':' + now.getSeconds();
            window.ws.send("2" + "\0" + nickName + "\0" + time);
            window.ws.close();
        }
    });
})();