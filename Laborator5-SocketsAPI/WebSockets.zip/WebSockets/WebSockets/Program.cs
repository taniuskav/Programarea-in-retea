﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Security.Cryptography.X509Certificates;

namespace Fleck.Samples.ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            FleckLog.Level = LogLevel.Debug;
            var allSockets = new List<IWebSocketConnection>();
            var server = new WebSocketServer("ws://0.0.0.0:8181");

            List<String> users = new List<String>();

            string[] data;

            server.Start(socket =>
            {
                socket.OnOpen = () =>
                {
                    Console.WriteLine("Open!");
                    allSockets.Add(socket);               
                };

                socket.OnClose = () =>
                {
                    Console.WriteLine("Close!");
                    allSockets.Remove(socket);
                };

                socket.OnMessage = message =>
                {
                    // get message type
                    string type = message.Substring(0, 1);
                    string temp;
                    data = message.Replace("\0", ",").Split(',');
             
                    switch (type)
                    {
                        // user came online
                        case "1": 
                             users.Add(data[1]);
                             temp = "1" + "\0" + data[1] + "\0" + data[2] + "\0" + "Joins the net";
                             allSockets.ToList().ForEach(s => s.Send(temp));
                             Console.WriteLine(temp);
                             break;
                        
                        // user leaves the net
                        case "2":
                             temp = message + "\0" + "Leaves the net";
                             allSockets.ToList().ForEach(s => s.Send(temp));
                             Console.WriteLine(temp);
                            break;

                        // private message
                        case "/":                             
                            int index = 0;
                            int index1 = 0;
                            for (int i = 0; i < users.Count; i++)
                            {
                                if (users[i].CompareTo(data[1]) == 0)
                                {
                                    index = i;
                                    Console.WriteLine("Exists" + index);
                                }
                                else if (users[i].CompareTo(data[2]) == 0)
                                {
                                    index1 = i;
                                }
                            }
                            
                            temp = "/" + "\0" + data[1] + "\0" + data[2] + "\0" + data[3] + "\0" + data[4] + "\0" + "PM from <" + data[2] +">";
                            allSockets.ElementAt(index).Send(temp);
                            allSockets.ElementAt(index1).Send(temp);
                            Console.WriteLine(temp);
                            break;

                        // send message to all users
                        default:
                            temp = data[0] + "\0" + data[1] + "\0" + data[2];
                            allSockets.ToList().ForEach(s => s.Send(temp));
                            Console.WriteLine(temp);
                            break;
                    }
                  
                };
            });
            
            Console.ReadLine();
        }        
    }
}
